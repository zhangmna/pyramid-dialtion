#! /bin/bash
rm -rf __pycache__
rm \.*\.swp
rm -R ../logdir/*
rm -R ../showdir/*
rm ../models/*
